from django.contrib import admin
from . models import Produc

admin.site.register(Produc)

# Register your models here.
